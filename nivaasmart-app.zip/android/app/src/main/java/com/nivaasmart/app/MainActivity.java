package com.nivaasmart.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
