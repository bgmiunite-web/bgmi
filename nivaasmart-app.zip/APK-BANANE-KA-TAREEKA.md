# APK Kaise Banayein — Bina Android Studio Install Kiye

Yeh sabse aasan tareeka hai agar aap turant apne phone mein app install karke
dekhna chahte ho, bina Android Studio download kiye. GitHub ka **free**
cloud build service use karega, jiske paas poora internet access hai (jo
humare paas nahi tha), isliye yeh genuinely APK bana dega.

## Step 1 — GitHub account banao (agar nahi hai)
[github.com](https://github.com) par jao → "Sign up" → free account banao
(2 minute ka kaam).

## Step 2 — Naya repository banao
1. GitHub par login karke, top-right "+" icon → **New repository**.
2. Naam do: `nivaasmart-app` (ya kuch bhi).
3. **Private** select karo (taaki koi aur na dekhe) ya Public, aapki marzi.
4. "Create repository" dabao.

## Step 3 — Poora project upload karo
1. Naye (khaali) repository page par, **"uploading an existing file"** link
   par click karo.
2. Apne computer mein `nivaasmart-app` poora folder kholo, saari files aur
   folders (android, www, .github, sab) select karo, browser mein
   **drag-and-drop** kar do.
3. Neeche "Commit changes" button dabao. Upload hone mein 1-2 minute
   lagenge (kaafi files hain).

## Step 4 — Build apne aap shuru ho jayegi
1. Repository ke top mein **"Actions"** tab par click karo.
2. Ek build chal rahi dikhegi ("Build NivaasMart APK") — peela/orange
   circle ka matlab chal raha hai, **green tick** ka matlab ho gaya.
3. Isme lagbhag **5-8 minute** lagte hain. Page refresh karte rehna.

## Step 5 — APK download karo
1. Jab green tick aa jaye, us build ke naam par click karo.
2. Sabse neeche **"Artifacts"** section mein `nivaasmart-debug-apk` naam
   ki ek file dikhegi — usko click karke download karo.
3. Yeh ek `.zip` file hogi — usko extract karo, andar `app-debug.apk`
   milegi. **Yehi aapki app hai.**

## Step 6 — Phone mein install karo
1. `app-debug.apk` file ko apne Android phone mein bhejo (WhatsApp khud ko
   message karke, Google Drive se, ya USB cable se copy karke).
2. Phone mein us file par tap karo.
3. Pehli baar mein phone puchega "Install unknown apps?" — allow kar do
   (yeh normal hai, kyunki yeh Play Store se nahi hai abhi).
4. Install ho jayegi — icon home screen par aa jayega, khol ke dekho!

## Agar build fail ho jaye (red X)
Red X par click karke jo error dikhe uska screenshot bhej dena, turant
theek kar dunga.

## Baad mein website update karne ke baad
Website (PHP) update karne se app **automatically** naya content dikhayegi
— app ko dobara build karne ki zaroorat sirf tab hai jab icon/naam/permissions
jaisi native cheezein badalni ho.
