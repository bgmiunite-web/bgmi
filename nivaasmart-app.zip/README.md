# NivaasMart Android App — Setup Guide

Yeh ek **Capacitor Hybrid App** hai — aapki live website (`nivaasmart.com/estate/`)
ko ek native Android app ke andar wrap karta hai, plus Camera aur Push
Notifications jaisi native features ke saath.

## Yeh project kaise bana hai
- Framework: **Capacitor** (Ionic team ka, actively maintained, industry-standard)
- App website ko LIVE load karta hai (`capacitor.config.json` mein `server.url`) —
  matlab jab bhi aap website update karoge (jaisa hum abhi tak karte aaye hain),
  app apne aap naya content dikhayega. App ko dobara build karne ki zaroorat
  sirf tab hai jab icon/naam/permissions jaisi native cheezein badalni ho.
- Plugins already installed: Camera, Push Notifications, Splash Screen, Status Bar
- App icon aur splash screen aapke brand logo (`nivaasmart-icon.png` /
  `nivaasmart-logo-gold.png`) se generate kiye gaye hain — sab density sizes
  (mdpi se xxxhdpi tak) ke saath.

## Step 1 — Android Studio mein kholna
1. [Android Studio](https://developer.android.com/studio) install karo (free).
2. `nivaasmart-app` folder ko **poora** copy karo apne computer par.
3. Android Studio kholo → **Open** → `nivaasmart-app/android` folder select karo
   (note: `android` sub-folder, poora `nivaasmart-app` nahi).
4. Pehli baar kholne par Android Studio khud Gradle aur zaroori tools download
   karega (internet chahiye, thoda time lagega) — normal hai, ek hi baar hota hai.

## Step 2 — Test karna (bina Play Store ke)
1. Android Studio ke top mein ek phone/emulator select karo (ya apna Android phone
   USB se connect karo, "Developer Options → USB Debugging" on karke).
2. Green ▶️ "Run" button dabao.
3. App aapke phone/emulator mein install ho jayegi aur website load karegi.

## Step 3 — Push Notifications on karna (Firebase, zaroori manual step)
Push notifications ke liye Firebase Cloud Messaging chahiye — yeh Google ka
free service hai, iske liye aapka apna Google account chahiye (main yeh
aapke liye nahi kar sakta, kyunki yeh aapka account hai):

1. [Firebase Console](https://console.firebase.google.com/) par jao → "Add Project"
   → naam do "NivaasMart" → create.
2. Project ke andar → Android icon par click → app add karo:
   - Package name: `com.nivaasmart.app` (bilkul yehi likhna, exact match zaroori hai)
3. `google-services.json` file download hogi — usko
   `nivaasmart-app/android/app/` folder ke andar rakh do (exactly wahi jagah
   jahan `build.gradle` file hai).
4. Android Studio mein project ko "Sync" karo (upar ek bar dikhega "Sync Now").
5. Ab push notifications kaam karengi. Jab tak yeh file nahi daalte, baaki poora
   app (website, camera, sab) waise hi kaam karta rahega — sirf notifications
   off rahengi.

Push notification **bhejne** ke liye (jaise "Naya Lead Aaya" wala alert), Firebase
Console ke "Cloud Messaging" section se ya humare PHP backend se Firebase API
call karke bheja ja sakta hai — yeh agla step hai jab aap ready ho.

## Step 4 — App ka icon/naam/color badalna hai kabhi
- Icon: `android/app/src/main/res/mipmap-*/ic_launcher.png` (har density folder mein)
- Naam: `android/app/src/main/res/values/strings.xml` mein `app_name`
- Status bar color: `capacitor.config.json` mein `StatusBar.backgroundColor`
- Yeh sab badalne ke baad: `npx cap sync android` chalao, phir Android Studio
  mein dobara Run karo.

## Step 5 — Play Store ke liye Release Build
1. Android Studio → Build → Generate Signed Bundle/APK.
2. "Android App Bundle" (.aab) chuno — Play Store ab isi format ko prefer karta hai.
3. Ek naya "keystore" banao (yeh ek password-protected file hai jo saabit karti
   hai ki app aapki hi hai — isko **bahut safe** rakhna, kho gaya to future
   updates publish nahi kar paoge).
4. Build hone ke baad `.aab` file [Play Console](https://play.google.com/console)
   par upload karo (Play Console account banane ka one-time $25 fee Google leta hai).

## Camera Integration (website ke liye)
Camera plugin already installed hai. Jab website ke andar koi "Upload Photo"
button ho (jaise property photo upload), aur agar app ke andar khula ho, to
website ka JavaScript native camera ko directly call kar sakta hai (browser
ke plain file-picker ki jagah) — yeh ek chhota JS snippet hai jo main
website ke code mein add kar sakta hoon jab aap ready ho.

## Sawal ho to
Yeh poora project genuine Capacitor CLI se generate hua hai (haath se nahi
likha), isliye structure 100% standard hai. Agar Android Studio mein koi
error aaye, screenshot bhej dena — turant dekh lunga.
